package com.fariz.karyawan.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaryawanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
